#!/usr/bin/env python3
"""
Quick test script to verify DDP + LoRA training works
Run with: python test_ddp_fix.py
"""

import torch
import torch.distributed as dist
import os

def test_basic_setup():
    """Test if basic setup works"""
    print("Testing basic setup...")
    
    # Check CUDA
    if not torch.cuda.is_available():
        print("❌ CUDA not available")
        return False
    print(f"✓ CUDA available: {torch.cuda.device_count()} GPUs")
    
    # Check if running in distributed mode
    world_size = int(os.environ.get("WORLD_SIZE", 1))
    if world_size > 1:
        print(f"✓ Distributed mode: {world_size} processes")
    else:
        print("✓ Single GPU mode")
    
    return True

def test_model_loading():
    """Test if model loads correctly"""
    print("\nTesting model loading...")
    
    from transformers import AutoModelForCausalLM, AutoTokenizer
    
    try:
        # Try to load tokenizer
        tokenizer = AutoTokenizer.from_pretrained("GAIR/Abel-7B-002")
        print("✓ Tokenizer loaded")
        
        # Try to load a small model for testing (not full Abel)
        # For actual test, replace with Abel model
        print("  Loading model (this may take a minute)...")
        model = AutoModelForCausalLM.from_pretrained(
            "GAIR/Abel-7B-002",
            torch_dtype=torch.float16,
            device_map="auto" if int(os.environ.get("WORLD_SIZE", 1)) == 1 else None
        )
        print("✓ Model loaded successfully")
        return True
        
    except Exception as e:
        print(f"❌ Model loading failed: {e}")
        return False

def test_lora_application():
    """Test if LoRA can be applied"""
    print("\nTesting LoRA application...")
    
    from transformers import AutoModelForCausalLM
    from peft import LoraConfig, get_peft_model
    
    try:
        # Load small model for testing
        model = AutoModelForCausalLM.from_pretrained(
            "GAIR/Abel-7B-002",
            torch_dtype=torch.float16,
            device_map="cuda:0"
        )
        
        # Apply LoRA
        lora_config = LoraConfig(
            r=8,  # Small rank for testing
            lora_alpha=16,
            target_modules=["q_proj", "v_proj"],  # Minimal targets
            task_type="CAUSAL_LM",
        )
        
        model = get_peft_model(model, lora_config)
        print(f"✓ LoRA applied: {model.get_nb_trainable_parameters()}")
        
        # Test forward pass
        dummy_input = torch.randint(0, 32000, (1, 64)).cuda()
        output = model(dummy_input, labels=dummy_input)
        loss = output.loss
        print(f"✓ Forward pass works, loss: {loss.item():.4f}")
        
        # Test backward pass
        loss.backward()
        print("✓ Backward pass works")
        
        return True
        
    except Exception as e:
        print(f"❌ LoRA test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_gradient_checkpointing():
    """Test gradient checkpointing compatibility"""
    print("\nTesting gradient checkpointing...")
    
    from transformers import AutoModelForCausalLM
    from peft import LoraConfig, get_peft_model
    
    try:
        model = AutoModelForCausalLM.from_pretrained(
            "GAIR/Abel-7B-002",
            torch_dtype=torch.float16,
            device_map="cuda:0"
        )
        
        # Enable gradient checkpointing
        model.gradient_checkpointing_enable()
        
        # Apply LoRA
        lora_config = LoraConfig(
            r=8,
            lora_alpha=16,
            target_modules=["q_proj", "v_proj"],
            task_type="CAUSAL_LM",
        )
        model = get_peft_model(model, lora_config)
        
        # Test
        dummy_input = torch.randint(0, 32000, (1, 64)).cuda()
        output = model(dummy_input, labels=dummy_input)
        loss = output.loss
        loss.backward()
        
        print("✓ Gradient checkpointing works with LoRA")
        return True
        
    except RuntimeError as e:
        if "Expected to mark a variable ready only once" in str(e):
            print("❌ Gradient checkpointing conflicts with DDP")
            print("  → Solution: Disable gradient checkpointing for multi-GPU")
        else:
            print(f"❌ Gradient checkpointing failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def main():
    print("=" * 60)
    print("DDP + LoRA Training Test Suite")
    print("=" * 60)
    
    results = []
    
    # Run tests
    results.append(("Basic Setup", test_basic_setup()))
    results.append(("Model Loading", test_model_loading()))
    results.append(("LoRA Application", test_lora_application()))
    
    # Only test gradient checkpointing in single GPU mode
    if int(os.environ.get("WORLD_SIZE", 1)) == 1:
        results.append(("Gradient Checkpointing", test_gradient_checkpointing()))
    
    # Summary
    print("\n" + "=" * 60)
    print("Test Summary:")
    print("=" * 60)
    
    for test_name, passed in results:
        status = "✓ PASSED" if passed else "❌ FAILED"
        print(f"{test_name:.<30} {status}")
    
    all_passed = all(r[1] for r in results)
    
    if all_passed:
        print("\n🎉 All tests passed! You can proceed with training.")
        print("\nRecommended command:")
        if int(os.environ.get("WORLD_SIZE", 1)) > 1:
            print("torchrun --nproc_per_node=8 train_abel_ddp_fixed.py")
        else:
            print("python train_abel_ddp_fixed.py")
    else:
        print("\n⚠️ Some tests failed. Please check the errors above.")
        print("\nTroubleshooting:")
        print("1. For multi-GPU: Disable gradient checkpointing")
        print("2. Try single GPU first: CUDA_VISIBLE_DEVICES=0 python train_abel_ddp_fixed.py")
        print("3. Check model access: Ensure you can access GAIR/Abel-7B-002")
    
    print("=" * 60)

if __name__ == "__main__":
    main()
