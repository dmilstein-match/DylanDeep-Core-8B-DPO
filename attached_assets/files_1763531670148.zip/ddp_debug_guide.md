# DDP + Gradient Checkpointing + LoRA Conflict Resolution Guide

## The Problem
Your training is failing with:
```
RuntimeError: Expected to mark a variable ready only once.
Parameter at index 255 with name base_model.model.model.layers.31.self_attn.o_proj.lora_B.default.weight 
has been marked as ready twice.
```

This is a **known conflict** between:
- **DDP (Distributed Data Parallel)** - which expects each parameter to be used once per backward pass
- **Gradient Checkpointing** - which recomputes forward passes during backward, potentially using parameters multiple times
- **LoRA** - which adds complexity to the parameter tracking

## Solution 1: Disable Gradient Checkpointing (RECOMMENDED)
The simplest and most reliable fix:

```python
# In training config
gradient_checkpointing=False,  # Disable completely

# Remove these lines:
# model.gradient_checkpointing_enable()
# gradient_checkpointing_kwargs={...}
```

**Pros:** Simple, reliable, works immediately
**Cons:** Uses more GPU memory (~20-30% more)

## Solution 2: Single GPU Testing
Test if the model works without DDP:

```bash
# Single GPU only
CUDA_VISIBLE_DEVICES=0 python train_sft_abel.py

# Or explicitly disable DDP
python train_sft_abel.py --num_processes 1
```

## Solution 3: Use FSDP Instead of DDP
FSDP (Fully Sharded Data Parallel) handles gradient checkpointing better:

```python
# In your SFTConfig
sft_config = SFTConfig(
    # ... other configs ...
    
    # Enable FSDP
    fsdp="full_shard auto_wrap",
    fsdp_config={
        "backward_prefetch": "backward_pre",
        "forward_prefetch": True,
        "use_orig_params": True,
        "cpu_ram_efficient_loading": True,
        "sync_module_states": True,
        "activation_checkpointing": True,  # FSDP's gradient checkpointing
    },
)
```

Launch with:
```bash
accelerate launch --config_file fsdp_config.yaml train_sft_abel.py
```

## Solution 4: Fix Gradient Checkpointing Settings
If you must use gradient checkpointing with DDP:

```python
# 1. Use non-reentrant checkpointing
model.gradient_checkpointing_enable(
    gradient_checkpointing_kwargs={"use_reentrant": False}
)

# 2. In SFTConfig
gradient_checkpointing_kwargs={"use_reentrant": False},
ddp_find_unused_parameters=False,  # Or True if needed

# 3. After creating trainer with DDP wrapper
if hasattr(trainer.model, "module"):
    trainer.model._set_static_graph()  # Tell DDP the graph won't change
```

## Solution 5: DeepSpeed Integration
DeepSpeed handles this better than vanilla DDP:

```bash
# Install DeepSpeed
pip install deepspeed

# Create DeepSpeed config
cat > ds_config.json << EOF
{
    "train_batch_size": "auto",
    "gradient_accumulation_steps": "auto",
    "gradient_clipping": 1.0,
    "zero_optimization": {
        "stage": 2,
        "offload_optimizer": {
            "device": "cpu",
            "pin_memory": true
        },
        "allgather_bucket_size": 5e8,
        "reduce_bucket_size": 5e8
    },
    "fp16": {
        "enabled": "auto"
    }
}
EOF

# Launch with DeepSpeed
deepspeed --num_gpus=8 train_sft_abel.py --deepspeed ds_config.json
```

## Solution 6: Manual DDP Fixes
For advanced users - manually handle DDP:

```python
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP

# Initialize process group
dist.init_process_group(backend="nccl")

# Wrap model manually
model = DDP(
    model,
    device_ids=[local_rank],
    output_device=local_rank,
    find_unused_parameters=False,
    broadcast_buffers=False,
    bucket_cap_mb=25,
    gradient_as_bucket_view=True,  # Memory optimization
)

# If using gradient checkpointing
if use_gradient_checkpointing:
    # Use static graph mode
    model._set_static_graph()
```

## Solution 7: Reduce Complexity
Sometimes simplifying helps identify the issue:

```python
# 1. Reduce LoRA targets (fewer parameters to track)
target_modules=["q_proj", "v_proj"],  # Just 2 instead of 7

# 2. Smaller batch size
per_device_train_batch_size=1,

# 3. No gradient accumulation
gradient_accumulation_steps=1,

# 4. Disable mixed precision
bf16=False,
fp16=False,
```

## Quick Diagnostic Script
Test your setup with this minimal script:

```python
import torch
from transformers import AutoModelForCausalLM
from peft import get_peft_model, LoraConfig

# Load model
model = AutoModelForCausalLM.from_pretrained(
    "GAIR/Abel-7B-002",
    torch_dtype=torch.float16,
    device_map="cuda:0"
)

# Apply LoRA
peft_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    task_type="CAUSAL_LM",
)
model = get_peft_model(model, peft_config)

# Test forward pass
dummy_input = torch.randint(0, 32000, (1, 128)).cuda()
output = model(dummy_input, labels=dummy_input)
loss = output.loss

# Test backward pass
loss.backward()
print("✓ Basic LoRA training works!")
```

## Recommended Approach

### For Immediate Fix:
1. **Disable gradient checkpointing** (Solution 1)
2. Run with your 8 GPUs normally

### For Memory-Constrained Scenarios:
1. Try **FSDP** (Solution 3)
2. Or use **DeepSpeed** (Solution 5)

### For Debugging:
1. Test with **single GPU** first (Solution 2)
2. Gradually scale up to multi-GPU

## Memory Estimates (Per GPU)

| Configuration | Memory Usage |
|--------------|--------------|
| Base + LoRA | ~14-16 GB |
| + Gradient Checkpointing | ~10-12 GB |
| + Batch Size 4 | +4-6 GB |
| + Seq Length 512 | +2-3 GB |
| **Total (no checkpoint)** | ~20-25 GB |
| **Total (with checkpoint)** | ~16-20 GB |

With H100 80GB, you have plenty of headroom to disable gradient checkpointing.

## Launch Commands

```bash
# Option 1: Vanilla DDP (gradient checkpointing disabled)
torchrun --nproc_per_node=8 train_abel_ddp_fixed.py

# Option 2: Accelerate (recommended)
accelerate launch --multi_gpu --num_processes=8 train_abel_ddp_fixed.py

# Option 3: Single GPU test
python train_abel_ddp_fixed.py

# Option 4: FSDP
accelerate launch --use_fsdp --fsdp_auto_wrap_policy TRANSFORMER_BASED_WRAP train_abel_ddp_fixed.py
```

## Environment Variables for Debugging

```bash
# More verbose errors
export TORCH_SHOW_CPP_STACKTRACES=1
export TORCH_DISTRIBUTED_DEBUG=DETAIL

# NCCL debugging
export NCCL_DEBUG=INFO
export NCCL_DEBUG_SUBSYS=ALL

# Disable P2P (sometimes helps)
export NCCL_P2P_DISABLE=1

# Run your script
torchrun --nproc_per_node=8 train_sft_abel.py
```

## Still Having Issues?

Try this fail-safe configuration:

```python
# Absolute minimum config that should work
sft_config = SFTConfig(
    output_dir=OUTPUT_DIR,
    num_train_epochs=1,
    per_device_train_batch_size=1,
    gradient_accumulation_steps=1,
    learning_rate=2e-4,
    max_seq_length=256,  # Shorter sequences
    gradient_checkpointing=False,  # Disabled
    bf16=False,  # No mixed precision
    fp16=False,
    ddp_find_unused_parameters=True,  # Find any unused params
    save_strategy="no",  # Don't save during training
    logging_steps=1,
    report_to="none",
)
```

Then gradually increase complexity once it's working.
