#!/bin/bash
# Launch scripts for Abel-7B training with DDP fixes

echo "Abel-7B Training Launcher"
echo "========================="
echo ""

# Function to check GPU availability
check_gpus() {
    if ! command -v nvidia-smi &> /dev/null; then
        echo "❌ nvidia-smi not found. No GPUs detected."
        exit 1
    fi
    
    GPU_COUNT=$(nvidia-smi -L | wc -l)
    echo "✓ Found $GPU_COUNT GPU(s)"
    return $GPU_COUNT
}

# Main menu
show_menu() {
    echo "Select training mode:"
    echo "--------------------"
    echo "1) Single GPU (Safest - with gradient checkpointing)"
    echo "2) Single GPU (Fast - no gradient checkpointing)"
    echo "3) Multi-GPU DDP (8 GPUs - gradient checkpointing disabled)"
    echo "4) Multi-GPU FSDP (8 GPUs - experimental)"
    echo "5) Test setup only (verify everything works)"
    echo "6) Custom configuration"
    echo "0) Exit"
    echo ""
}

# Check GPUs
check_gpus
GPU_COUNT=$?

# Show menu and get selection
show_menu
read -p "Enter selection [0-6]: " selection

case $selection in
    1)
        echo ""
        echo "Starting single GPU training with gradient checkpointing..."
        echo "Command: CUDA_VISIBLE_DEVICES=0 python train_abel_ddp_fixed.py"
        echo ""
        CUDA_VISIBLE_DEVICES=0 python train_abel_ddp_fixed.py
        ;;
    
    2)
        echo ""
        echo "Starting single GPU training without gradient checkpointing..."
        echo "Note: This will use more memory but train faster"
        echo ""
        # Modify the script to disable gradient checkpointing
        sed 's/use_gradient_checkpointing = False/use_gradient_checkpointing = False/' train_abel_ddp_fixed.py > temp_train.py
        CUDA_VISIBLE_DEVICES=0 python temp_train.py
        rm temp_train.py
        ;;
    
    3)
        echo ""
        echo "Starting multi-GPU DDP training (8 GPUs)..."
        echo "Gradient checkpointing disabled for stability"
        echo "Command: torchrun --nproc_per_node=8 train_abel_ddp_fixed.py"
        echo ""
        torchrun --nproc_per_node=8 train_abel_ddp_fixed.py
        ;;
    
    4)
        echo ""
        echo "Starting multi-GPU FSDP training (experimental)..."
        echo "This may provide better memory efficiency"
        echo ""
        
        # Create FSDP config
        cat > fsdp_config.yaml << EOF
compute_environment: LOCAL_MACHINE
distributed_type: FSDP
fsdp_config:
  fsdp_auto_wrap_policy: TRANSFORMER_BASED_WRAP
  fsdp_backward_prefetch_policy: BACKWARD_PRE
  fsdp_forward_prefetch: true
  fsdp_offload_params: false
  fsdp_sharding_strategy: FULL_SHARD
  fsdp_state_dict_type: FULL_STATE_DICT
  fsdp_sync_module_states: true
  fsdp_use_orig_params: true
machine_rank: 0
main_process_ip: null
main_process_port: null
main_training_function: main
mixed_precision: fp16
num_machines: 1
num_processes: 8
use_cpu: false
EOF
        
        accelerate launch --config_file fsdp_config.yaml train_abel_ddp_fixed.py
        ;;
    
    5)
        echo ""
        echo "Running test suite..."
        echo ""
        python test_ddp_fix.py
        ;;
    
    6)
        echo ""
        read -p "Enter number of GPUs to use [1-$GPU_COUNT]: " num_gpus
        read -p "Enable gradient checkpointing? (y/n) [n]: " use_gc
        read -p "Batch size per device [2]: " batch_size
        batch_size=${batch_size:-2}
        
        echo ""
        echo "Starting custom configuration:"
        echo "- GPUs: $num_gpus"
        echo "- Gradient checkpointing: $use_gc"
        echo "- Batch size: $batch_size"
        echo ""
        
        if [ "$num_gpus" == "1" ]; then
            CUDA_VISIBLE_DEVICES=0 python train_abel_ddp_fixed.py
        else
            torchrun --nproc_per_node=$num_gpus train_abel_ddp_fixed.py
        fi
        ;;
    
    0)
        echo "Exiting..."
        exit 0
        ;;
    
    *)
        echo "Invalid selection"
        exit 1
        ;;
esac

echo ""
echo "Training completed or interrupted."
echo ""

# Check if checkpoints were saved
if [ -d "checkpoints/abel_sft_lora" ]; then
    echo "✓ Checkpoints saved in: checkpoints/abel_sft_lora"
    echo ""
    echo "To use your fine-tuned model:"
    echo "------------------------------"
    cat << 'EOF'
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

# Load base model
model = AutoModelForCausalLM.from_pretrained("GAIR/Abel-7B-002")
tokenizer = AutoTokenizer.from_pretrained("checkpoints/abel_sft_lora")

# Load LoRA weights
model = PeftModel.from_pretrained(model, "checkpoints/abel_sft_lora")

# Generate
prompt = "Problem: What is 15 + 27?"
inputs = tokenizer(prompt, return_tensors="pt")
outputs = model.generate(**inputs, max_new_tokens=200)
print(tokenizer.decode(outputs[0]))
EOF
fi
