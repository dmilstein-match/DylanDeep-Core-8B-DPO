import os
import json
from dataclasses import dataclass
from typing import List, Dict
import warnings

import torch
import torch.distributed as dist
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset, Dataset
from trl import SFTTrainer, SFTConfig
from peft import LoraConfig, prepare_model_for_kbit_training

# H100 optimization flags
torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = True
torch.backends.cuda.enable_flash_sdp(True)
torch.backends.cuda.enable_mem_efficient_sdp(True)

BASE_MODEL = "GAIR/Abel-7B-002"
TRAIN_PATH = "data/gsm8k_train.jsonl"
OUTPUT_DIR = "checkpoints/abel_sft_lora"


def formatting_func(example) -> Dict[str, str]:
    """Format single example as tutoring-style prompt with step-by-step solution."""
    q = example.get("question", "")
    a = example.get("answer", "")
    
    prompt = (
        "You are a careful math tutor. Solve the problem step-by-step, "
        "then give the final answer in the format '#### 42'.\n\n"
        f"Problem:\n{q}\n\nSolution:\n{a}"
    )
    
    return {"text": prompt}


def main():
    print("=" * 80)
    print("Abel-7B-002 SFT Training with LoRA (DDP-Fixed)")
    print("=" * 80)
    
    # Get rank info for distributed training
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    world_size = int(os.environ.get("WORLD_SIZE", 1))
    rank = int(os.environ.get("RANK", 0))
    
    print(f"Process rank: {rank}, Local rank: {local_rank}, World size: {world_size}")
    
    # Check if CUDA is available
    if not torch.cuda.is_available():
        print("WARNING: CUDA not available. Training will be very slow on CPU.")
    
    # Load dataset
    print(f"\nLoading GSM8K training data from {TRAIN_PATH}...")
    
    try:
        dataset = load_dataset(
            "json",
            data_files={"train": TRAIN_PATH},
            split="train",
        )
        print(f"Loaded {len(dataset)} training examples\n")
        
    except FileNotFoundError:
        print(f"File not found: {TRAIN_PATH}")
        print("Creating dummy dataset for testing...")
        
        dummy_data = [
            {"question": "What is 2+2?", "answer": "Let me solve this step by step.\n2 + 2 = 4\n#### 4"},
            {"question": "What is 5*3?", "answer": "Let me calculate:\n5 × 3 = 15\n#### 15"},
            {"question": "What is 10-3?", "answer": "Subtracting:\n10 - 3 = 7\n#### 7"},
            {"question": "What is 8/2?", "answer": "Dividing:\n8 ÷ 2 = 4\n#### 4"},
        ] * 60  # Replicate to have enough data for multi-GPU
        dataset = Dataset.from_list(dummy_data)
        print(f"Created dummy dataset with {len(dataset)} examples for testing\n")

    # Load tokenizer
    print(f"Loading tokenizer from {BASE_MODEL}...")
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    
    # Detect dtype support
    use_bf16 = torch.cuda.is_bf16_supported() if torch.cuda.is_available() else False
    dtype = torch.bfloat16 if use_bf16 else torch.float16
    dtype_name = "bfloat16" if use_bf16 else "float16"
    
    print(f"Loading Abel base model in {dtype_name}...")
    
    # CRITICAL FIX 1: Load model properly for DDP
    # Don't use device_map="auto" with DDP - let DDP handle device placement
    try:
        model = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL,
            torch_dtype=dtype,
            # device_map=None,  # IMPORTANT: Let DDP handle device placement
            trust_remote_code=True,
        )
        
        # Move model to correct device BEFORE wrapping with DDP
        if torch.cuda.is_available():
            model = model.to(f"cuda:{local_rank}")
            
    except Exception as e:
        print(f"Error loading model: {e}")
        print("Make sure you have access to the GAIR/Abel-7B-002 model on HuggingFace")
        return

    # CRITICAL FIX 2: Gradient checkpointing configuration
    # Option A: Disable gradient checkpointing entirely (simplest fix)
    use_gradient_checkpointing = False
    
    # Option B: If you must use gradient checkpointing, prepare model properly
    if use_gradient_checkpointing:
        print("WARNING: Gradient checkpointing with LoRA + DDP can be unstable.")
        print("If training fails, disable gradient checkpointing.")
        
        # Prepare model for gradient checkpointing BEFORE LoRA
        model.gradient_checkpointing_enable()
        
        # CRITICAL: Set use_reentrant=False for gradient checkpointing
        # This helps avoid the DDP conflict
        if hasattr(model, "gradient_checkpointing_enable"):
            model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    else:
        print("Gradient checkpointing disabled for stability with DDP + LoRA")
    
    # Enable input gradients for PEFT
    model.enable_input_require_grads()

    # LoRA configuration
    lora_config = LoraConfig(
        r=16,
        lora_alpha=32,
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj"
        ],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
    )

    # Training configuration - OPTIMIZED FOR DDP
    sft_config = SFTConfig(
        output_dir=OUTPUT_DIR,
        num_train_epochs=1,
        per_device_train_batch_size=2,  # Start conservative
        gradient_accumulation_steps=2,   # Effective batch = 4 per device
        learning_rate=2e-4,
        warmup_steps=100,
        max_seq_length=512,
        bf16=use_bf16,
        fp16=not use_bf16 and torch.cuda.is_available(),
        logging_steps=10,
        save_steps=200,
        save_total_limit=3,
        
        # CRITICAL FIX 3: DDP-specific settings
        gradient_checkpointing=use_gradient_checkpointing,
        gradient_checkpointing_kwargs={"use_reentrant": False} if use_gradient_checkpointing else None,
        
        # CRITICAL FIX 4: Use DDP settings properly
        ddp_find_unused_parameters=False,  # Set to True if you get unused parameter errors
        ddp_bucket_cap_mb=25,  # Tune based on your network
        ddp_broadcast_buffers=False,  # Can help with memory
        
        optim="adamw_torch",
        seed=42,
        report_to="none",
        remove_unused_columns=False,
        dataset_text_field="text",
        
        # Additional stability settings
        max_grad_norm=1.0,  # Gradient clipping for stability
        dataloader_num_workers=2,  # Reduce if you get dataloader errors
        dataloader_pin_memory=True if torch.cuda.is_available() else False,
        
        # Save strategy
        save_strategy="steps",
        save_only_model=True,  # Only save model weights, not optimizer state
    )

    # CRITICAL FIX 5: Alternative - Use FSDP instead of DDP (if available)
    # Uncomment to try FSDP which handles gradient checkpointing better
    """
    sft_config.fsdp = "full_shard auto_wrap"
    sft_config.fsdp_config = {
        "backward_prefetch": "backward_pre",
        "forward_prefetch": True,
        "use_orig_params": True,
        "cpu_ram_efficient_loading": True,
        "sync_module_states": True,
    }
    """

    # Create trainer
    try:
        trainer = SFTTrainer(
            model=model,
            tokenizer=tokenizer,
            peft_config=lora_config,
            train_dataset=dataset,
            formatting_func=formatting_func,
            args=sft_config,
            max_seq_length=sft_config.max_seq_length,
        )
        
        # CRITICAL FIX 6: Set static graph for DDP if using gradient checkpointing
        if use_gradient_checkpointing and hasattr(trainer.model, "module"):
            if hasattr(trainer.model.module, "_set_static_graph"):
                print("Setting static graph for DDP stability...")
                trainer.model.module._set_static_graph()
        
    except Exception as e:
        print(f"Error creating trainer: {e}")
        import traceback
        traceback.print_exc()
        return

    # Calculate and display batch size information
    print("\nTraining Configuration:")
    print("-" * 40)
    per_device_batch = sft_config.per_device_train_batch_size
    grad_accum = sft_config.gradient_accumulation_steps
    effective_batch = per_device_batch * grad_accum
    global_batch = effective_batch * world_size
    
    print(f"Per-device batch size: {per_device_batch}")
    print(f"Gradient accumulation steps: {grad_accum}")
    print(f"Effective batch size per device: {effective_batch}")
    print(f"Number of GPUs: {world_size}")
    print(f"Global batch size: {global_batch}")
    print(f"Max sequence length: {sft_config.max_seq_length}")
    print(f"Learning rate: {sft_config.learning_rate}")
    print(f"Gradient checkpointing: {use_gradient_checkpointing}")
    print(f"Total training steps: ~{len(dataset) // global_batch}")
    print("-" * 40)
    print()

    # Train with error handling
    print("Starting Abel SFT (LoRA) training...")
    print("This may take a while depending on dataset size and hardware.\n")
    
    try:
        trainer.train()
        
    except RuntimeError as e:
        if "Expected to mark a variable ready only once" in str(e):
            print("\n" + "="*60)
            print("DDP + Gradient Checkpointing Conflict Detected!")
            print("="*60)
            print("\nThis is a known issue with DDP + LoRA + Gradient Checkpointing.")
            print("\nSolutions to try:")
            print("1. Set use_gradient_checkpointing=False in the script (recommended)")
            print("2. Use FSDP instead of DDP (uncomment FSDP config in script)")
            print("3. Reduce the number of GPUs to 1 for debugging")
            print("4. Try setting ddp_find_unused_parameters=True")
            print("\nRecommended command for single-GPU debugging:")
            print("CUDA_VISIBLE_DEVICES=0 python train_abel_ddp_fixed.py")
            print("="*60)
        else:
            print(f"\nTraining error occurred: {e}")
            import traceback
            traceback.print_exc()
        return
    
    except Exception as e:
        print(f"\nUnexpected training error: {e}")
        import traceback
        traceback.print_exc()
        return

    # Save model (only on rank 0 to avoid conflicts)
    if rank == 0:
        print(f"\nSaving LoRA adapter and tokenizer to {OUTPUT_DIR}...")
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        
        trainer.save_model(OUTPUT_DIR)
        tokenizer.save_pretrained(OUTPUT_DIR)
        
        # Save training configuration
        config_path = os.path.join(OUTPUT_DIR, "training_config.json")
        with open(config_path, "w") as f:
            json.dump({
                "base_model": BASE_MODEL,
                "lora_r": lora_config.r,
                "lora_alpha": lora_config.lora_alpha,
                "max_seq_length": sft_config.max_seq_length,
                "learning_rate": sft_config.learning_rate,
                "batch_size": global_batch,
                "num_epochs": sft_config.num_train_epochs,
                "world_size": world_size,
                "gradient_checkpointing": use_gradient_checkpointing,
            }, f, indent=2)
        
        print("=" * 80)
        print("Abel SFT training complete!")
        print(f"LoRA adapter saved to: {OUTPUT_DIR}")
        print(f"Training config saved to: {config_path}")
        print("=" * 80)


if __name__ == "__main__":
    main()
